const mongoose = require("mongoose");

const progressSchema = new mongoose.Schema({

  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User"
  },

  completedLessons: {
    type: Number,
    default: 0
  },

  quizScores: [Number],

  accuracy: {
    type: Number,
    default: 0
  },

  learningStreak: {
    type: Number,
    default: 0
  }

}, { timestamps: true });

module.exports = mongoose.model("Progress", progressSchema);