const Progress = require("../models/Progress");

exports.saveProgress = async (req, res) => {

  try {

    const progress = await Progress.create(req.body);

    res.json(progress);

  } catch (error) {

    res.status(500).json({ error: error.message });

  }

};

exports.getProgress = async (req, res) => {

  try {

    const progress = await Progress.findOne({
      userId: req.params.userId
    });

    res.json(progress);

  } catch (error) {

    res.status(500).json({ error: error.message });

  }

};