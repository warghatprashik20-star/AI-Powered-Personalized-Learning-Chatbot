const axios = require("axios");

exports.chatAI = async (req, res) => {

  try {

    const { message } = req.body;

    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [
          { role: "user", content: message }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
        }
      }
    );

    res.json({
      answer: response.data.choices[0].message.content
    });

  } catch (error) {

    res.status(500).json({
      error: "AI error"
    });

  }

};

exports.generateQuiz = async (req, res) => {

  try {

    const { topic, difficulty, questions } = req.body;

    const prompt = `Generate ${questions} ${difficulty} quiz questions about ${topic} with 4 options and correct answer.`;

    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [
          { role: "user", content: prompt }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
        }
      }
    );

    res.json({
      quiz: response.data.choices[0].message.content
    });

  } catch (error) {

    res.status(500).json({
      error: "Quiz generation failed"
    });

  }

};