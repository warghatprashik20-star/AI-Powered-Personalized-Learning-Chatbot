const express = require("express");

const {
  chatAI,
  generateQuiz
} = require("../controllers/aiController");

const router = express.Router();

router.post("/chat", chatAI);
router.post("/generate-quiz", generateQuiz);

module.exports = router;