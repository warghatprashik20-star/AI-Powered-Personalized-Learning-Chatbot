const express = require("express");

const {
  saveProgress,
  getProgress
} = require("../controllers/progressController");

const router = express.Router();

router.post("/save", saveProgress);
router.get("/:userId", getProgress);

module.exports = router;